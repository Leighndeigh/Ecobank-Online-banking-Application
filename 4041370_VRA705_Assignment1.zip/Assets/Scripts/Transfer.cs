using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using static SignIn;

public class Transfer : MonoBehaviour
{
    public InputField transferToIDInputField;
    public InputField transferAmountInputField;
    public Text balanceText;
    public Text messageDisplay;

    private float balance = 10000f;

    private string bankAPIURL = "https://jsonplaceholder.typicode.com/users/";
    private string name;

    public void TransferMoney() //This is the transfer method that will be called
    {
        int targetID;
        if (!int.TryParse(transferToIDInputField.text, out targetID))
        {
            messageDisplay.text = "Invalid target ID";
            Debug.Log("Invalid target ID");
            return;
        }

        float amount;
        if (!float.TryParse(transferAmountInputField.text, out amount))
        {
            messageDisplay.text = "Invalid amount";
            Debug.Log("Invalid amount");
            return;
        }

        // Perform money transfer
        StartCoroutine(TransferMoneyCoroutine(targetID, amount));
    }

    IEnumerator TransferMoneyCoroutine(int targetID, float amount) //This method is the API for the user to access the other users details
    {
        string url = bankAPIURL + targetID;
        UnityWebRequest webRequest = UnityWebRequest.Get(url);

        yield return webRequest.SendWebRequest();

        if (webRequest.result == UnityWebRequest.Result.Success)
        {
            // Parse JSON response
            string jsonResponse = webRequest.downloadHandler.text;
            BankUser targetUser = JsonUtility.FromJson<BankUser>(jsonResponse);

            if (targetUser != null)
            {
                if (balance >= amount)
                {
                    targetUser.balance += amount;
                    balance -= amount;
                    balanceText.text = "Balance: $" + balance;
                    messageDisplay.text = "Money transferred successfully";
                    Debug.Log("Money transferred successfully");
                }
                else
                {
                    messageDisplay.text = "Insufficient balance";
                    Debug.Log("Insufficient balance");
                }
            }
            else
            {
                messageDisplay.text = "Target user not found";
                Debug.Log("Target user not found");
            }
        }
        else
        {
            messageDisplay.text = "Failed to transfer money. Error: " + webRequest.error;
            Debug.Log("Failed to transfer money. Error: " + webRequest.error);
        }
    }

    public void MainMenu() // This method takes the user back to the Main Menu
    {
        SceneManager.LoadScene("MainMenu");
    }
}
