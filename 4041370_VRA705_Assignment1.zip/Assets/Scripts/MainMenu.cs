using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MainMenu : MonoBehaviour
{
    public void Deposit()
    {
        SceneManager.LoadScene("Deposit");
    }

    public void Transfer()
    {
        SceneManager.LoadScene("Transfer");
    }

    public void ExitWelcome()
    {
        SceneManager.LoadScene("Welcome");
    }
    
}
