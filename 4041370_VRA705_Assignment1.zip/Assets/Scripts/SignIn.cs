using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using UnityEngine.Networking;
using System.Net.Http;
using System.Threading.Tasks;
using static UnityEditor.Experimental.GraphView.GraphView;
using System;

public class SignIn : MonoBehaviour
{
    public Text message;
    public InputField username;
    public InputField password;
    public Text balanceText;

    private int loggedInUserID;
    private float balance;
    private string name;

    private string bankAPIURL = "https://jsonplaceholder.typicode.com/users/";

    /*void Start()
    {
        // Initialize UI
        UpdateBalanceDisplay();
    }*/

    public void LogIn()
    {
        int bankID;
        if (!int.TryParse(username.text, out bankID))
        {
            Debug.Log("Invalid bank ID");
            return;
        }

        string pin = password.text;

        // Perform authentication with bank API
        StartCoroutine(Authenticate(bankID, pin));
    }

    IEnumerator Authenticate(int bankID, string pin)
    {
        string url = bankAPIURL + bankID;
        UnityWebRequest webRequest = UnityWebRequest.Get(url);

        yield return webRequest.SendWebRequest();

        if (webRequest.result == UnityWebRequest.Result.Success)
        {
            // Parse JSON response
            string jsonResponse = webRequest.downloadHandler.text;
            BankUser bankUser = JsonUtility.FromJson<BankUser>(jsonResponse);

            if (bankUser != null /*&& bankUser.pin == pin*/)
            {
                loggedInUserID = bankUser.id;
                balance = bankUser.balance;

                message.text = "Logged in successfully";
                Debug.Log("Logged in successfully");
                SceneManager.LoadScene("MainMenu");
                //UpdateBalanceDisplay();
            }
            else
            {
                message.text = "Authentication failed. Incorrect bank ID or PIN.";
                Debug.Log("Authentication failed. Incorrect bank ID or PIN.");
            }
        }
        else
        {
            Debug.Log("Failed to authenticate. Error: " + webRequest.error);
        }
    }

    void UpdateBalanceDisplay()
    {
        balanceText.text = "Balance: $" + balance.ToString("0.00");
    }

    [Serializable]
    public class BankUser
    {
        public int id;
        public string name;
        public string username;
        public string pin;
        public float balance;
    }
}
