using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Deposit : MonoBehaviour
{
    public InputField amountInput;
    public Text messageText;
    public Text balanceText;

    private double balance = 10000f;
    public string amount;

    public void Depositt()
    {
        string amount = amountInput.text;
        // Deposit the amount
        double amountt = double.Parse(amount);
        balance += amountt;
        balanceText.text = "Balance: $" + balance;
        messageText.text = "Deposit successful!";
        Debug.Log("Deposit successful!");
       
    }

    public void MainMenu()
    {
        SceneManager.LoadScene("MainMenu");
    }
}
