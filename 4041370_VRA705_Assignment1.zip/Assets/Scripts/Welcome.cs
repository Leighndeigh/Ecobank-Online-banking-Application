using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Welcome : MonoBehaviour
{
    public void SignIn() // This method takes the user to the sign-in page
    {
        SceneManager.LoadScene("SignIn");
    }

    
}
